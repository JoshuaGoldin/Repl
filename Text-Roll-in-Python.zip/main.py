f=open("file.txt")
line=[]
nLines=f.readline()
bL=0
for i in range(int(nLines)):
  line.append(f.readline())
for i in range(len(line)):
  pass
lineNum=0
for lineNum in range(int(nLines)):
  for spaceLoc in range(len(line[lineNum])):
    if line[lineNum][spaceLoc]==" ":
      if bL<=spaceLoc:
        bL=spaceLoc
        break
print bL+1